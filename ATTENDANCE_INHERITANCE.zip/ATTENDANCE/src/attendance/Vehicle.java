package attendance;

public class Vehicle {
	int ToyotaSpeed = 55;
	String ToyotaColor = "Red";
	String ToyotaPrice = "₱ 1,005,000";
	
	int PlaneSpeed = 800;
	String PlaneColor = "Dark Blue";
	String PlanePrice = "$120,000,000";
	
	int YachtSpeed = 28;
	String YachtColor = "Black";
	String YachtPrice = "$2,495,000";
	
	
	void Stop(){
		System.out.println("The Vehicle has stopped");
	}
	

}


