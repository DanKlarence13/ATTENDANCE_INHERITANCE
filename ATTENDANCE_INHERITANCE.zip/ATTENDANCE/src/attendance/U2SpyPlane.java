package attendance;

public class U2SpyPlane extends Vehicle {
	
	 int WingSpan = 103;
		
		void Fly() {
			System.out.println("The Plane is flying");
		}
		
		
		@Override
		void Stop() {
			super.Stop();
		}

}