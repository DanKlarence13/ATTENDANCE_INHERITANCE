package attendance;

public class ToyotaVios  extends Vehicle {
	
    String TireType = "All Season Tire";
	
	void Drive() {
		System.out.println("The Car is accelerating");
	}
	
	
	@Override
	void Stop() {
	super.Stop();
	}

}
